<?php include('includes/header.php'); ?>

	<h3 class="col-md-10 col-md-offset-2 right-content-10 header"><?= $page->title; ?></h3>

	<div class="col-md-10 col-md-offset-2 right-content-10">

		<div class="row">

			<div class="page">

				<div class="page-body">
					<?= $page->body ?>
				</div>

			</div>

		</div>
    

	</div> 


<?php include('includes/footer.php'); ?>