<?php foreach($videos as $video): ?>
<div class="col-md-3 col-sm-6 col-xs-12 loop">
	<?php include('video-block.php'); ?>
</div>
<?php endforeach; ?>