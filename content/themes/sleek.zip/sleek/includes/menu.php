<ul class="nav navbar-nav navbar-left">

	<?= generate_menu($menu); ?>

</ul>