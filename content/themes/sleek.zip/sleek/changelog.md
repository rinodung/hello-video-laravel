### 1.0.3

- Fixed social share buttons in the footer to link to correct social networks
- If user has spaces in image filenames such as image background, I've added the rawurlencode function to url encode them
- Added Gulpfiles for css compiling
- Fixed Menu Items when they don't show correctly from multi ul to next
- Added custom 404 page
