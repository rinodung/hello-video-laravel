<?php

class VideoTag extends Eloquent {

	protected $table = 'tag_video';
	protected $guarded = array();

	public static $rules = array();

}