<?php namespace HelloVideo\Events;

abstract class Event {

	//

}
