<?php namespace HelloVideo\Commands;

abstract class Command {

	//

}
